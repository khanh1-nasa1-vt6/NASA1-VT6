# SELENE — Lunar Odyssey v2.2.1

Bản hoàn thiện cục bộ từ SELENE v2.2, commit nền 8a988ca2f2d08416b641412fa42fa76d0df51f2a, nhánh selene-v2.2-review của đội NASA1-VT6. Thực hiện ngày 14/11/2026 theo yêu cầu người dùng. Chưa commit, push, merge hoặc công bố.

## Chơi game

Giải nén toàn bộ gói rồi mở index.html bằng Chrome/Edge hiện đại. Giữ game-core.js, game-ui.js, science.js và game.css cùng thư mục. Game chạy ngoại tuyến; mở liên kết nguồn NASA cần mạng. Bản web có thể phục vụ toàn bộ thư mục bằng máy chủ tĩnh.

WASD/mũi tên di chuyển; E tương tác, giữ E 3 giây sửa; F ăn; C bế/đặt NOVA; G/H dùng cửa căn cứ/hầm khi ở gần; R ngủ tại giường; P tạm dừng. Có nút cảm ứng. Chọn kế hoạch điện mỗi ngày bằng bảng bên cạnh; không cần tới bàn điều khiển để chọn kế hoạch.

Hoàn thành 7 ngày, sửa 7 thiết bị và tạo tối thiểu 14 báo cáo. Trước khi kết thúc ngày 7, phải đưa NOVA về căn cứ; pin robot bằng 0 vẫn có thể bế về.

## Quản lý tài nguyên

- Bắt đầu với 5 phần trong túi và 30 phần ở kho. E tại kho bổ sung túi tới 5, trừ đúng số lấy. Kho không tự nạp.
- Khi độ no ≤30%, ăn bằng F trước sửa/lấy mẫu/ngủ. Một phần ăn tăng 35 độ no, tối đa 5 máu. Thưởng trắc nghiệm chỉ nhận một lần mỗi câu.
- Có 6 đêm giữa 7 ngày; mỗi đêm cần 1 phần ăn và 8 điện. Ngày cuối bàn giao không tiêu thụ thêm khẩu phần qua đêm. Bảng dự trù chỉ tính phần qua đêm; còn cần dự phòng ăn khi đói.
- Sửa tốn 3 điện. Kế hoạch tiết kiệm/cân bằng/nghiên cứu: quét 2/4/6 điện, sạc 1,5/3/3 điểm pin mỗi giây; nghiên cứu thưởng 2 điểm riêng mỗi lượt. Quét cần 6 giây hoạt động, có thể lâu hơn nếu tạm dừng.
- Máy phát trong căn cứ: +20 điện đổi 8 độ no, yêu cầu độ no >38. Dưỡng sinh dùng 0,025 điện/giây. Khi điện <5, hai phòng vẫn an toàn nhưng ôxy dự phòng chỉ hồi 2 điểm/giây thay vì 9.
- Bão hạt: ngày 3 giây 40–70 và ngày 6 giây 85–115. Quét/sạc tạm dừng, không mất dữ liệu. Sau khi sửa tấm chắn ngày 3, có thể bật bảo vệ thiết bị từ bảng bên cạnh để tiếp tục quét/sạc: tốn 0,18 điện/giây trong bão. Người ngoài bề mặt vẫn bị ảnh hưởng. Có thể chọn chờ hết bão để tiết kiệm điện.
- Hai phòng luôn bảo vệ người ở mức cơ bản. Vi thiên thạch và bão hạt là hai tình huống khác nhau. Không ngủ qua ngày khi hiểm họa đang diễn ra.

Mọi chỉ số, chi phí, thời gian, khả năng bảo vệ và mẫu phân tích là quy ước giáo dục. Chi phí điện của bảo vệ thiết bị đại diện chế độ điều khiển mô phỏng, không khẳng định vật liệu che chắn bức xạ phải dùng điện. Đây không phải công cụ thiết kế căn cứ hoặc chứng nhận NASA.

## Học và thảo luận

Mỗi ngày có mục tiêu, lựa chọn và câu hỏi suy ngẫm. Nhật ký quyết định tối đa 600 ký tự/ngày, chỉ lưu trên thiết bị, không gửi lên mạng và không chấm bằng AI. Không ghi thông tin cá nhân. Có thể sửa suy ngẫm trong lúc hành trình chưa kết thúc.

Tổng kết nêu việc đã làm tốt, điều nên cải thiện và câu hỏi thảo luận từ dữ liệu đã ghi. 100 điểm là thang nội bộ; không phải điểm BGK hoặc thước đo hiệu quả giáo dục đã được chuẩn hóa. Bản lưu cũ chỉ có thống kê mới kể từ khi cập nhật.

## Tài liệu và kiểm tra

- project.html: giới thiệu ngắn, năm tiêu chí, demo và giới hạn.
- docs/TEACHER.md: hướng dẫn buổi học và thu phản hồi thật.
- docs/CONTEST.md: đối chiếu thể lệ, quyền sử dụng, AI và thời điểm phát triển.
- docs/TESTING.md: kết quả kiểm thử, phạm vi và phần chưa xác minh.
- docs/CHANGELOG.md: thay đổi so với bản nền.

Chạy node tests/run.cjs: 67 kiểm tra đơn vị, chiến dịch 7 ngày, 7 lần save/restore giữa quét và UI mock. tests/browser-fixtures.html chỉ dành cho người kiểm thử, tạo trạng thái giả lập và thay bản lưu cục bộ của nguồn web hiện tại. Không dùng fixture làm bằng chứng chơi tự nhiên.

Đóng gói: python tools/package_game.py. Gói không chứa lại chính ZIP. Khi mở bằng file://, liên kết tải trong game chuyển thành hướng dẫn ngoại tuyến. Lưu tiến độ trên file:// hoặc chế độ riêng tư tùy trình duyệt; xuất nhật ký trước khi đóng nếu cần.

## Nguồn gốc và quyền

Mã, hình canvas và âm thanh tổng hợp: LICENSE.txt, giấy phép dạng MIT. Tài nguyên NASA và PDF đầu vào không được tái cấp phép trong gói. Có 9 thẻ khoa học, 8 URL NASA trong science.js; báo cáo và đáp án dẫn nguồn. Không có CDN, ảnh/font/nhạc ngoài, API AI hoặc tài khoản người chơi.

AI hỗ trợ phát triển: OpenAI ChatGPT/Codex — phân tích yêu cầu, viết/sửa mã, nội dung, kiểm thử và tài liệu. Đây là công cụ hỗ trợ phát triển, không phải AI vận hành game. Đội phải đưa kê khai này và các nguồn vào bài nộp chính thức.

Theo xác nhận của người dùng, v2.2 được đội phát triển sáng 14/11/2026. Git ghi nhận v2.2 lúc 11:27:59 giờ Việt Nam cùng ngày; bản tiền thân có từ 11/11. Bản v2.2.1 này là phiên hoàn thiện tiếp ngày 14/11, không được khai là đã có từ sáng hoặc thay thế bằng chứng đóng góp của thành viên.

Thể lệ PDF mâu thuẫn hạn nộp Hà Nội: trước 11:00 và 12:00 ngày 15/11/2026. Chuẩn bị trước 11:00 giờ Việt Nam và xác minh BTC. Không có xác nhận tư cách hợp lệ, đăng ký hoặc đóng góp cá nhân từ mã nguồn.
