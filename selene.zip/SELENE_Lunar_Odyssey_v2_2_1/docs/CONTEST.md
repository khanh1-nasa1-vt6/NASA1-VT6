# Đối chiếu thể lệ — SELENE v2.2.1

Căn cứ: PDF người dùng cung cấp “The le NASA Space App Ha Noi 2026.pdf”, 12 trang. Đã đối chiếu trang 4–5, 8 và 10–11. Không phân phối lại PDF trong gói. Đề đầy đủ thử thách 3 trả 502 trong lần rà soát trước; chưa xác nhận yêu cầu ngoài bản tóm tắt.

## Phù hợp thử thách 3

Game quản lý căn cứ Mặt Trăng cho học sinh: ôxy/dưỡng sinh; nơi trú và bão hạt; điện cho sửa/quét/sạc/bảo vệ; thức ăn hữu hạn và dự trù qua đêm. Bảy ngày là cấu trúc thiết kế của đội, không ghi là yêu cầu bắt buộc của PDF.

## Năm tiêu chí

| Tiêu chí | Bằng chứng trong bản này | Giới hạn |
|---|---|---|
| Impact | Tiếng Việt, ngoại tuyến, hướng dẫn giáo viên, câu hỏi trước/sau, mẫu thu phản hồi | Chưa có dữ liệu lớp học hoặc con số tác động |
| Creativity | Hai lựa chọn chờ bão/dùng điện bảo vệ, robot cần cứu, kế hoạch điện và khẩu phần qua đêm | Không tuyên bố độc nhất |
| Validity | Quy tắc nhất quán, nguồn NASA, 67 unit checks và chiến dịch lõi; ghi rõ giả định | Chưa có thẩm định chuyên gia; trình duyệt chỉ thử các luồng được liệt kê |
| Relevance | Bốn nhóm dưỡng sinh/che chắn/điện/lương thực đều có cơ chế quan sát được | Mô hình đơn giản, không có dữ liệu cảm biến thật hoặc liều bức xạ |
| Presentation | Hồ sơ gọn, demo 4 phút, gói offline, nhật ký và tổng kết học tập | Chưa xác minh link bài nộp chính thức |

Không đặt trọng số BGK. Điểm 100 trong game là thang nội bộ; câu suy ngẫm không tự động chấm.

## Nguồn, quyền và AI

science.js có 9 thẻ và 8 URL NASA: Moon Facts; Glenn Moon; Top Moon Questions; ECLSS; What Is Lunar Regolith?; The Lunar South Pole Region; Radiation Protection; Scientists Grow Plants in Lunar Soil. Tài nguyên được diễn giải và gắn với cơ chế/câu hỏi/báo cáo; không tuyên bố xử lý dữ liệu quan trắc thô. Mục IV.4 PDF cho phép dữ liệu mở hoặc tài nguyên khoa học.

Mã/nội dung gốc cấp phép dạng MIT trong LICENSE.txt. NASA/PDF không được tái cấp phép. Không kèm logo hoặc ảnh NASA. Đội tự xác nhận quyền đối với mọi tài nguyên đưa vào bài nộp, kể cả đầu vào có trước. OpenAI ChatGPT/Codex hỗ trợ phân tích, thiết kế, viết/sửa mã và nội dung, kiểm thử, tài liệu; không có AI hoặc API key trong game. Đưa công bố nguồn, AI và giấy phép vào bài nộp chính thức, không chỉ ở repository.

## Thời điểm phát triển và hồ sơ đội

Bản tiền thân trên GitHub ngày 11/11 có nhiều cơ chế lõi. Theo người dùng, đội phát triển v2.2 sáng 14/11; commit 8a988ca lúc 11:27:59 giờ Việt Nam. Bản v2.2.1 này được hoàn thiện tiếp trong phiên ngày 14/11, bắt đầu sau 16:00 giờ Việt Nam, không ghi ngược về buổi sáng. Chưa commit/push/merge/công bố. Không tự nhận phần kế thừa là mới, không đổi lịch sử.

Mục IV.2 yêu cầu phần lõi phát triển trong thời gian thi. Đội cần cung cấp lịch sử nguồn, bảng kế thừa/phát triển mới và bằng chứng đóng góp thật để BTC đánh giá. Mã không chứng minh đăng ký, tham gia phòng thi, quyền tác giả hay thành viên đã đóng góp. Ghi vai trò thật; hồ sơ phụ huynh khi cần để ở nơi riêng, không công bố dữ liệu trẻ em.

## Thời hạn

PDF trang 4 ghi trước 11:00 ngày 15/11/2026; trang 5 ghi 12:00 cùng ngày. Chuẩn bị trước 11:00 giờ Việt Nam và xin BTC xác nhận bằng văn bản. Hạn toàn cầu 23:59 cùng ngày là mốc trong PDF, chưa xác nhận độc lập qua cổng nộp.
