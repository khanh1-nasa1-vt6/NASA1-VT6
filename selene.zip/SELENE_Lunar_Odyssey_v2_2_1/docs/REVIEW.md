# Tình trạng xử lý rà soát

- Đã sửa: hướng dẫn thiếu điện; thắng khi bỏ NOVA; tọa độ save ngoài phòng; hướng dẫn chọn kế hoạch; đích tải ZIP được cung cấp khi đóng gói.
- Đã phát triển: đánh đổi bảo vệ thiết bị/điện; khẩu phần qua đêm; dự trù; bài học từng ngày; suy ngẫm và phản hồi có dẫn chứng.
- Chưa xác nhận: hiệu quả giáo dục, thiết bị vật lý, toàn bộ hành trình trong trình duyệt, thẩm định khoa học độc lập, quyền và đóng góp cá nhân, yêu cầu đề đầy đủ, hạn nộp do BTC quyết định.
- Chưa làm: push/merge/publish hoặc liên hệ BTC. Xem CONTEST.md, TESTING.md và TEACHER.md.
