# Kiểm thử SELENE v2.2.1 — ngày 14/11/2026

## Tự động

Chạy node tests/run.cjs trong bản làm việc cục bộ. Bộ gồm 22 kiểm tra lõi, 11 quiz/chỉ dẫn, 16 tài nguyên, 18 learning/hồi quy = 67 unit checks; chiến dịch bảy ngày bằng di chuyển tương đương WASD; bảy lần lưu/khôi phục giữa quét; UI smoke dùng DOM/canvas mock. Xem các JSON trong tests. Không dùng kết quả JSON cũ làm bằng chứng cho bản sửa nếu chưa chạy lại.

Các ca mới kiểm tra: thiếu điện dẫn về máy phát; chọn kế hoạch không trỏ sai vị trí; chặn thắng khi bỏ NOVA; qua đêm thiếu thức ăn/điện không trừ tài nguyên; qua đêm trừ đúng; ngày 7 không trừ thêm đêm; không ngủ trong bão; quét/sạc tạm dừng và tiếp tục; bảo vệ hết điện tự tắt; ôxy dự phòng; suy ngẫm giữ qua reload/retry; save theo giới hạn phòng; dự trù và phản hồi theo dữ liệu thật.

Chiến dịch không dịch chuyển hoặc bơm tài nguyên: đi bộ qua các phòng, chờ robot, sửa, lấy mẫu, giao, sạc, ăn, lấy đồ từ kho và ngủ. Một số unit tests có gán trạng thái để cô lập quy tắc; không coi đó là chơi tự nhiên. Luồng campaign chọn kế hoạch luân phiên, chủ động trú chờ các hiểm họa.

## Trình duyệt thật đã thực hiện

Trình duyệt tích hợp trên máy trong phiên 14/11/2026, nguồn localhost riêng. Đây là kiểm tra ứng dụng bằng người điều khiển tự động, không phải nghiên cứu người học.

- Mở trang, canvas vẽ, các bảng số liệu và nút động xuất hiện.
- Chọn kế hoạch Tiết kiệm; mở suy ngẫm, nhập nội dung, lưu, tải lại, Tiếp tục và mở lại: nội dung còn nguyên.
- Bằng fixture bão hạt ngày 6: nút Bật bảo vệ hoạt động, trạng thái hiển thị quét/sạc tiếp tục. Thời gian quét còn được hiển thị đúng.
- Bằng fixture NOVA ngoài căn cứ: phím R không kết thúc, nhật ký yêu cầu đưa NOVA về.
- Bằng fixture bàn giao: phím R mở kết thúc, có phản hồi việc đã làm tốt/cần cải thiện, câu hỏi thảo luận và suy ngẫm đã ghi.
- Viewport 390×844: màn hình đầu và hộp suy ngẫm hiển thị; không tràn ngang. Đây là mô phỏng kích thước trong browser, không phải điện thoại vật lý hoặc xác nhận mọi thao tác cảm ứng.

Fixture ở tests/browser-fixtures.html phải được mở bằng hồ sơ riêng. Nút fixture thay bản lưu cục bộ của nguồn hiện tại. Dữ liệu được ghi rõ là giả lập; không dùng ảnh fixture làm bằng chứng đã chơi 7 ngày trong browser.

## Cần đội kiểm tra tiếp

- Hành trình đủ 7 ngày trên trình duyệt thật; Chrome/Edge phiên bản của máy thi, mở file://, chính sách localStorage.
- Giữ E và pointer capture trên điện thoại vật lý, đa chạm, xoay màn hình, bàn phím và trình đọc màn hình.
- Thử mất tập trung/tab, đóng/mở lại khi đang quét/sạc và tình huống thất bại/thử lại trên máy thi.
- Chơi thử với học sinh, ghi phản hồi thật theo TEACHER.md; thẩm định khoa học độc lập.
- Kiểm tra URL bài nộp/deploy khi đội công bố. Trong phiên này chưa publish, push hoặc merge.

Không có xác nhận lớp học, độ tuổi phù hợp đã được thực nghiệm, đóng góp thành viên, quyền tác giả hoặc tư cách hợp lệ dự thi.
