# Hướng dẫn giáo viên — SELENE v2.2.1

## Đối tượng và mục tiêu

Nhóm mục tiêu thiết kế: học sinh khoảng 10–15 tuổi, có người hướng dẫn; đây là giả định thiết kế, chưa được xác nhận qua thử nghiệm lớp học. Học sinh nhỏ hơn có thể chơi theo cặp cùng người lớn.

Sau buổi học, học sinh được kỳ vọng giải thích được: cấp O₂ khác loại CO₂; nơi trú giúp giảm rủi ro; điện dùng chung tạo đánh đổi; kho hữu hạn cần dự trù; tín hiệu mẫu mô phỏng không xác nhận nước uống. Đây là mục tiêu, không phải kết quả đã đo.

## Một buổi học 25–35 phút

1. Chuẩn bị 3 phút: mở game đã giải nén, thử âm thanh/tạm dừng, giới thiệu chỉ số và các nút. Không cần tài khoản hoặc tên thật.
2. Hỏi trước 3 phút: “Ôxy đầy có cần loại CO₂ không?”, “Điện ít nên làm gì trước?”, “Tìm thấy dấu hiệu băng có uống ngay được không?”. Ghi lời giải thích, không chỉ đánh dấu đúng/sai.
3. Chơi theo cặp 12–18 phút: một em điều khiển, một em quan sát tài nguyên; đổi vai giữa buổi. Mỗi ngày chọn kế hoạch và ghi 1–2 câu lý do. Có thể tạm dừng để đọc nguồn.
4. Thảo luận 5 phút: so sánh hai lựa chọn chờ bão hoặc dùng điện bảo vệ thiết bị; hỏi điều kiện khiến phương án của mỗi nhóm hợp lý.
5. Hỏi sau 3–5 phút: dùng cùng nội dung kiến thức, yêu cầu giải thích bằng ví dụ trong game. Xuất nhật ký và đọc phản hồi hành trình.

Nếu thời gian ngắn, chỉ chơi 1–2 ngày rồi dùng phần trao đổi; không ép hoàn thành 7 ngày. Trang fixture chỉ để giáo viên chuẩn bị demo tình huống, phải nói rõ là dữ liệu giả lập.

## Quan sát và phản hồi

Ghi mã nhóm ẩn danh, trình duyệt, thời lượng thật, thao tác gây vướng, lời giải thích trước/sau và một đề xuất cải thiện. Không thu tên, địa chỉ, ngày sinh hoặc hình trẻ em nếu chưa có cơ sở đồng ý phù hợp. Không đưa nhật ký người học lên GitHub.

Mẫu ghi nhận chưa điền:

| Mã nhóm | Thiết bị/trình duyệt | Câu hỏi trước: giải thích | Câu hỏi sau: giải thích | Điểm vướng | Góp ý |
|---|---|---|---|---|---|
| | | | | | |

Điểm trong game không thay cho đánh giá của giáo viên. Không dùng một vài lượt chơi để khẳng định hiệu quả cho mọi học sinh. Báo cáo đúng số người, thời gian và phương pháp thực tế; để trống khi chưa thu dữ liệu.

## Câu hỏi mở

- Nếu em tiết kiệm điện, em chấp nhận đánh đổi thời gian gì?
- Vì sao phải đưa NOVA về dù đã đủ báo cáo?
- Khi nào chờ an toàn hợp lý hơn tiếp tục nghiên cứu?
- Dữ kiện nào là của NASA, con số nào là luật game?
- Nếu bỏ phần thưởng trắc nghiệm, kế hoạch tiếp tế của em thay đổi thế nào?
