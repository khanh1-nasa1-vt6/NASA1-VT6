# Tài nguyên khoa học NASA

- https://science.nasa.gov/moon/facts/
- https://www1.grc.nasa.gov/beginners-guide-to-aeronautics/moon/
- https://science.nasa.gov/moon/top-moon-questions/
- https://www.nasa.gov/reference/environmental-control-and-life-support-systems-eclss/
- https://science.nasa.gov/biological-physical/what-is-lunar-regolith/
- https://www.nasa.gov/reference/moonbase-environment/
- https://www.nasa.gov/radiation-protection/
- https://www.nasa.gov/humans-in-space/scientists-grow-plants-in-lunar-soil/

Diễn giải tiếng Việt nằm trong science.js. Chỉ số game và cơ chế bảo vệ dùng điện là quy ước giáo dục, không lấy từ các tài liệu này. Không kèm hoặc tái cấp phép ảnh/logo/PDF của NASA. AI hỗ trợ phát triển: OpenAI ChatGPT/Codex.
