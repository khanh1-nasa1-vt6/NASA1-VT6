# Lịch sử và phạm vi thay đổi

## V2.2.1 — phiên hoàn thiện ngày 14/11/2026

Nền: GitHub commit 8a988ca2f2d08416b641412fa42fa76d0df51f2a, nhánh selene-v2.2-review. Đây là bản làm việc cục bộ mới; chưa có commit SHA mới. Không thay đổi ngày hoặc tác giả lịch sử Git. Phiên hoàn thiện sau 16:00 giờ Việt Nam; không khai là đã làm từ buổi sáng.

- Sửa chỉ dẫn thiếu điện và chọn kế hoạch; không chỉ người chơi tới bàn điều khiển để bấm kế hoạch ở sidebar.
- Chặn thắng nếu NOVA còn ngoài căn cứ; có thể bế robot hết pin về.
- Kiểm tra tọa độ save theo phòng, thêm trường mới có mặc định để đọc save v2.2 hợp lệ. Không cam kết nhập được định dạng khác của game inline ngày 11/11.
- Mỗi đêm trừ 1 phần ăn và 8 điện, kiểm tra đủ trước khi ngủ; ngày cuối không tính thêm đêm.
- Dưỡng sinh dùng điện, có ôxy dự phòng khi điện thấp; hai phòng vẫn không mất máu.
- Bão hạt ngày 6 bổ sung; quét/sạc tạm dừng hoặc dùng điện cho chế độ bảo vệ sau sửa shield; dữ liệu giữ nguyên.
- Thêm mục tiêu/quyết định/câu hỏi từng ngày, dự trù, nhật ký suy ngẫm và phản hồi từ dữ liệu thực tế.
- Thêm 18 ca kiểm thử; cập nhật chiến dịch theo luật mới; kiểm thử trình duyệt tách khỏi mock.
- Viết hướng dẫn giáo viên, hồ sơ gọn, kịch bản demo, đóng gói ZIP và điều hướng ngoại tuyến.

AI hỗ trợ: OpenAI ChatGPT/Codex. Không có người học thực tham gia kiểm thử trong phiên này; không ghi nhận kết quả lớp học hoặc đóng góp của từng thành viên khi chưa có chứng cứ.

## Lịch sử có trước

Người dùng xác nhận v2.2 phát triển sáng 14/11/2026; Git ghi nhận 11:27:59 giờ Việt Nam. Bản tiền thân đã có từ 11/11. CHANGELOG v2.2 nhắc Sites SHA 9ed26b2, 3a93350, c11f427; chưa xác minh metadata hoặc diff của những SHA này. Không coi chúng là tổ tiên GitHub đã được chứng minh.
